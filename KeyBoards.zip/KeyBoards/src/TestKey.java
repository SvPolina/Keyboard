import javax.swing.*;

public class TestKey {

	public static void main(String[] args)
	 {
	Key textKey = new Key();
	
	JFrame window = new JFrame("Welcome to Virtual KeyBoard!");
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setSize(900,600);
    window.add(textKey);
    window.setVisible(true);
	}
}
