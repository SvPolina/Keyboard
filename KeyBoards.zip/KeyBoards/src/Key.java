import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.awt.*;


public class Key extends JPanel
{
private final JTextArea textArea;  	
private final JPanel buttonJPanel;
private final JPanel buttonJPanel1;
private final JPanel buttonJPanel2;
private final JPanel buttonJPanel3;
private final JPanel buttonJPanel4;
private final JButton[] buttons;
int count;
boolean caps_press,shift_press;

public Key()
{	

textArea = new JTextArea(20,80);
buttons = new JButton[55];
buttonJPanel = new JPanel();
buttonJPanel1 = new JPanel();
buttonJPanel2 = new JPanel();
buttonJPanel3 = new JPanel();
buttonJPanel4 = new JPanel();

//First Row buttons 
String[] let=new String[54];
let[0]="`/~";let[1]="1/!";let[2]="2/@";let[3]="3/#";let[4]="4/$";let[5]="5/%";let[6]="6/^";let[7]="7/&";
let[8]="8/*";let[9]="9/(";let[10]="0/)";let[11]="-/_";let[12]="=/+";let[13]="Backspace";

//Second row buttons 
let[14]="Tab";let[15]="Q";let[16]="W";let[17]="E";let[18]="R";let[19]="T";let[20]="Y";let[21]="U";let[22]="I";let[23]="O";let[24]="P";
let[25]="[/{";let[26]="]/}";let[27]="\\/|";

//Third row buttons 
let[28]="Caps";let[29]="A";let[30]="S";let[31]="D";let[32]="F";let[33]="G";let[34]="H";let[35]="J";let[36]="K";let[37]="L";
let[38]=";/:";let[39]="'/\"";let[40]="Enter";

//Forth row buttons 
let[41]="Shift";let[42]="Z";let[43]="X";let[44]="C";let[45]="V";let[46]="B";let[47]="N";let[48]="M";
let[49]=",/<";let[50]="./>";let[51]="//?";let[52]="Shift";

//Fifth row buttons 
let[53]="";


//Place buttons in 5 panels
for (int c = 0; c< 54; c++)
{buttons[c] = new JButton(let[c]);}

for (int c = 0; c< 14; c++){
buttonJPanel.add(buttons[c]);		
}
for (int c = 14; c< 28; c++){
buttonJPanel1.add(buttons[c]);		
}
for (int c = 28; c< 41; c++){
buttonJPanel2.add(buttons[c]);		
}
for (int c = 41; c< 53; c++){
buttonJPanel3.add(buttons[c]);		
}
buttonJPanel4.add(buttons[53]);	

buttons[53].setPreferredSize(new Dimension(400, 30));




for (count = 15; count < 49; count++){
	if((count>24&&count<29)||(count>37&&count<42)){count++;}
	else{String label=let[count];
	buttons[count].addActionListener(		
			new ActionListener() //	
			{//set text letter in the text area to upper (caps pressed) or lower case letter (caps not pressed)
			@Override
			public void actionPerformed(ActionEvent event)
			{   if (false==caps_press)				
			    textArea.append(label.toLowerCase());			     
			    else 
			    textArea.append(label); 
			}	
			}
			);}
			}

count=0;
while(count<53)	 {
if ((count<13)||(count>24&&count<28) || (count>37&&count<40) || (count>48&&count<52)) { 
	String label=let[count];
	buttons[count].addActionListener(		
			new ActionListener() //	
			{//set text letter in the text area to character on the left (shit not pressed) or on right (shift pressed) side of a button with double characters
			@Override
			public void actionPerformed(ActionEvent event)
			{   if (false==shift_press)
				textArea.append(label.substring(0,1));						
			    else 
			     textArea.append(label.substring(2));					    
			}}                      ); 
	count++;}
else{count++;}	}
	


// create new SpecialButton for button event handling
SpecialButton SpecialB = new SpecialButton();
buttons[53].addActionListener(SpecialB);
buttons[52].addActionListener(SpecialB);
buttons[41].addActionListener(SpecialB);
buttons[40].addActionListener(SpecialB);
buttons[28].addActionListener(SpecialB);
buttons[14].addActionListener(SpecialB);
buttons[13].addActionListener(SpecialB);



JPanel keys=new JPanel(new GridLayout(5,1));
keys.add(buttonJPanel);
keys.add(buttonJPanel1);
keys.add(buttonJPanel2);
keys.add(buttonJPanel3);
keys.add(buttonJPanel4);

textArea.setEditable(false);

this.add(textArea,BorderLayout.NORTH);
this.add(keys,BorderLayout.SOUTH);
}

//event handling class
private class SpecialButton implements ActionListener
{
		@Override	
	public void actionPerformed(ActionEvent event)
	 { String label=event.getActionCommand();
	   Color oldColor = buttons[53].getBackground();
	  if (label.equals(""))
		  		textArea.append(" ");
	  
	  else if (label.equals("Tab"))
		  		textArea.append("    ");
	  
	  else if (label.equals("Enter"))
			 	textArea.append("\n");
	  
	  else if (label.equals("Backspace"))
	  			{
		          try{ Delete(textArea);}
		          catch (IllegalArgumentException IllegalArgumentException){ JOptionPane.showMessageDialog(null, "The text area is empty");	}
	  			}
	  
	  else if (label.equals("Caps"))
	  			{caps_press=!caps_press; 
	  			if (caps_press==true) buttons[28].setBackground(Color.green);
	  			else buttons[28].setBackground(oldColor);
	  			}
	  
	  else if (label.equals("Shift"))
	            {shift_press=!shift_press;
	            if (shift_press==true) {buttons[41].setBackground(Color.green);buttons[52].setBackground(Color.green);}
	  			else {buttons[41].setBackground(oldColor);buttons[52].setBackground(oldColor); }
	            }	  
}
}


//Delete text method that throws exception
public void Delete(JTextArea MyText) throws IllegalArgumentException {
	MyText.replaceRange("",MyText.getCaretPosition()-1,MyText.getCaretPosition());
}


}